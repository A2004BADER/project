import chromadb
from sentence_transformers import SentenceTransformer, CrossEncoder
from rank_bm25 import BM25Okapi
import pandas as pd

places_data = [
    {
        "id": 0,
        "name": "ספריית זלמן ארן (אוניברסיטת בן גוריון)",
        "description": "מרחב אקדמי שקט מאוד המיועד ללמידה מעמיקה, מחקר וקריאת ספרים. הכניסה לסטודנטים בלבד.",
        "category": "לימודים"
    },
    {
        "id": 1,
        "name": "בר 'הספריה' (The Library)",
        "description": "דאנס-בר תוסס במרכז העיר. למרות השם המטעה, יש כאן מוזיקה רועשת, קוקטיילים ואווירה של מסיבה בלילה.",
        "category": "חיי לילה"
    },
    {
        "id": 2,
        "name": "המרכז הרפואי סורוקה",
        "description": "בית חולים אוניברסיטאי המעניק שירותי בריאות מתקדמים על ידי רופאים מומחים וסגל פרא-רפואי.",
        "category": "בריאות"
    },
    {
        "id": 3,
        "name": "פארק קרסו למדע",
        "description": "מוזיאון אינטראקטיבי לילדים ונוער בעיר העתיקה. מציג תערוכות על טכנולוגיה, פיזיקה וביולוגיה.",
        "category": "חינוך ופנאי"
    },
    {
        "id": 4,
        "name": "קניון הנגב (עזריאלי)",
        "description": "מרכז קניות ותיק ליד התחנה המרכזית. כולל חנויות אופנה, מתחם אוכל מהיר ובתי קולנוע.",
        "category": "שופינג"
    },
    {
        "id": 5,
        "name": "פארק נחל באר שבע",
        "description": "ריאה ירוקה בדרום העיר עם אגם מלאכותי גדול, מסלולי אופניים ומרחבים פתוחים לפיקניק.",
        "category": "טבע"
    },
    {
        "id": 6,
        "name": "מסעדת איטלקיה בתחנה",
        "description": "מטבח איטלקי מסורתי המגיש פסטה בעבודת יד, פיצות בתנור אבן ומנות טבעוניות מעולות.",
        "category": "אוכל"
    },
    {
        "id": 7,
        "name": "מתחם גב-ים נגב",
        "description": "פארק הייטק המאכלס חברות טכנולוגיה, סטרטאפים ומרכזי פיתוח בינלאומיים.",
        "category": "תעסוקה"
    },
    {
        "id": 8,
        "name": "מרכז הטניס באר שבע",
        "description": "מתחם ספורט הכולל מגרשי טניס מקצועיים, חוגים לילדים ואימוני כושר אישיים.",
        "category": "ספורט"
    },
    {
        "id": 9,
        "name": "העיר העתיקה - גלריית טרומפלדור",
        "description": "מרכז אמנות המציג תערוכות מתחלפות של אמנים ישראלים באווירה היסטורית ושקטה.",
        "category": "תרבות"
    }
]

documents = [
    f"{place['name']} {place['description']} {place['category']}"
    for place in places_data
]

ids = [str(place["id"]) for place in places_data]

embedding_model = SentenceTransformer(
    "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
)

client = chromadb.Client()

collection = client.create_collection(
    name="beersheva_places"
)

embeddings = embedding_model.encode(documents).tolist()

collection.add(
    documents=documents,
    embeddings=embeddings,
    ids=ids
)
# =========================
# Vector Search
# =========================

def vector_search(query, top_k=5):
    query_embedding = embedding_model.encode([query]).tolist()

    results = collection.query(
        query_embeddings=query_embedding,
        n_results=top_k
    )

    return [int(i) for i in results["ids"][0]]


# =========================
# BM25
# =========================

tokenized_docs = [doc.split() for doc in documents]

bm25 = BM25Okapi(tokenized_docs)

def bm25_search(query, top_k=5):
    tokenized_query = query.split()

    scores = bm25.get_scores(tokenized_query)

    ranked = sorted(
        range(len(scores)),
        key=lambda i: scores[i],
        reverse=True
    )

    return ranked[:top_k]


# =========================
# RRF
# =========================

def reciprocal_rank_fusion(
    vector_results,
    bm25_results,
    k=60
):
    scores = {}

    for rank, doc_id in enumerate(vector_results):
        scores[doc_id] = scores.get(doc_id, 0) + (
            1 / (k + rank + 1)
        )

    for rank, doc_id in enumerate(bm25_results):
        scores[doc_id] = scores.get(doc_id, 0) + (
            1 / (k + rank + 1)
        )

    ranked = sorted(
        scores.items(),
        key=lambda x: x[1],
        reverse=True
    )

    return [doc_id for doc_id, score in ranked]
# =========================
# Cross Encoder Reranking
# =========================

cross_encoder = CrossEncoder(
    "cross-encoder/mmarco-mMiniLMv2-L12-H384-v1"
)

def rerank(query, candidate_ids, top_k=5):

    pairs = [
        [query, documents[doc_id]]
        for doc_id in candidate_ids
    ]

    scores = cross_encoder.predict(pairs)

    ranked = sorted(
        zip(candidate_ids, scores),
        key=lambda x: x[1],
        reverse=True
    )

    return ranked[:top_k]


# =========================
# RAG Search
# =========================

def rag_search(query):

    vector_results = vector_search(query)

    bm25_results = bm25_search(query)

    fused_results = reciprocal_rank_fusion(
        vector_results,
        bm25_results
    )

    final_results = rerank(
        query,
        fused_results
    )

    print("\n" + "=" * 60)
    print("Query:", query)
    print("=" * 60)

    for doc_id, score in final_results:

        place = places_data[doc_id]

        print(f"\nName: {place['name']}")
        print(f"Category: {place['category']}")
        print(f"Score: {score:.4f}")
        print(f"Description: {place['description']}")

    return (
        vector_results,
        bm25_results,
        final_results
    )


# =========================
# Evaluation
# =========================

queries = [
    "מקום שקט ללמוד בו",
    "איפה אפשר לאכול פסטה טובה",
    "מקום עם מוזיקה וריקודים בלילה"
]

results_table = []

for query in queries:

    vector_results, bm25_results, final_results = rag_search(query)

    results_table.append({
        "Query": query,
        "Vector Top Result":
            places_data[vector_results[0]]["name"],
        "BM25 Top Result":
            places_data[bm25_results[0]]["name"],
        "Rerank Top Result":
            places_data[final_results[0][0]]["name"]
    })

df = pd.DataFrame(results_table)

print("\n")
print("=" * 60)
print("Evaluation Table")
print("=" * 60)
print(df)